// index.js
var express = require('express');
var app = express();
var cors = require('cors');

// Ativa o CORS para testes remotos pelo FCC
app.use(cors({ optionsSuccessStatus: 200 }));

// Serve arquivos estáticos da pasta /public
app.use(express.static('public'));

// Página inicial (HTML básico)
app.get("/", function (req, res) {
  res.sendFile(__dirname + '/views/index.html');
});

// Endpoint de teste
app.get("/api/hello", function (req, res) {
  res.json({ greeting: 'hello API' });
});

// ========== 🚀 ENDPOINT PRINCIPAL ==========
app.get("/api/:date?", function (req, res) {
  let dateInput = req.params.date;
  let date;

  // Sem parâmetro? Retorna data atual
  if (!dateInput) {
    date = new Date();
  } else {
    // Verifica se é um número (timestamp em milissegundos)
    if (!isNaN(dateInput) && /^\d+$/.test(dateInput)) {
      date = new Date(parseInt(dateInput)); // <- Corrigido aqui
    } else {
      date = new Date(dateInput); // Pode ser "2015-12-25" ou similar
    }
  }

  // Validação de data inválida
  if (date.toString() === "Invalid Date") {
    return res.json({ error: "Invalid Date" });
  }

  // Resposta JSON válida
  res.json({
    unix: date.getTime(),
    utc: date.toUTCString()
  });
});

// Inicia o servidor
var listener = app.listen(process.env.PORT || 3000, function () {
  console.log('Your app is listening on port ' + listener.address().port);
});

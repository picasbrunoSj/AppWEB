require('dotenv').config();
const express = require('express');
const cors = require('cors');
const dns = require('dns');

const app = express();
const port = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(`${process.cwd()}/public`));

// Banco de dados em memória
const urlDatabase = {};
let idCounter = 1;

// Página inicial
app.get('/', (req, res) => {
  res.sendFile(process.cwd() + '/views/index.html');
});

// Rota de teste
app.get('/api/hello', (req, res) => {
  res.json({ greeting: 'hello API' });
});

// ✅ POST: Recebe uma URL e retorna short_url
app.post('/api/shorturl', (req, res) => {
  const inputUrl = req.body.url;

  let hostname;
  try {
    hostname = new URL(inputUrl).hostname;
  } catch (err) {
    return res.json({ error: 'invalid url' });
  }

  dns.lookup(hostname, (err) => {
    if (err) {
      return res.json({ error: 'invalid url' });
    }

    const shortId = idCounter++;
    urlDatabase[shortId] = inputUrl;

    res.json({
      original_url: inputUrl,
      short_url: shortId
    });
  });
});

// ✅ GET: Redireciona usando o short_url
app.get('/api/shorturl/:id', (req, res) => {
  const id = req.params.id;
  const originalUrl = urlDatabase[id];

  if (originalUrl) {
    res.redirect(originalUrl);
  } else {
    res.json({ error: 'No short URL found for the given input' });
  }
});

// Inicia o servidor
app.listen(port, () => {
  console.log(`Listening on port ${port}`);
});
